<!-- FOOTER -->
<footer class="footer">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-12 col-sm-12 text-center">
                Copyright © <?php echo e(date("Y")); ?> <a href="<?php echo e(config('app.url')); ?>" target="_blank"><?php echo e(config('app.name')); ?></a>. <?php echo e(__('All rights reserved')); ?>

            </div>
        </div>
    </div>
</footer>
<!-- END FOOTER -->
<?php /**PATH /Users/softedel/Downloads/cloud-polly-1.0.1/cloudpolly/resources/views/layouts/footer.blade.php ENDPATH**/ ?>