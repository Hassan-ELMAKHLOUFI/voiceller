<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
	<head>
		<!-- Meta data -->
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="author" content="">
	    <meta name="keywords" content="">
	    <meta name="description" content="">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <!-- Title -->
        <title>Voiceller</title>

        <!--CSS Files -->
        <link href="<?php echo e(URL::asset('plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
	    <link href="<?php echo e(URL::asset('plugins/awselect/awselect.min.css')); ?>" rel="stylesheet" />

		<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</head>

	<body class="app sidebar-mini">

        <!-- LOADER -->
		<div id="global-loader" >
			<img src="<?php echo e(URL::asset('img/svgs/loader.svg')); ?>" alt="loader">
		</div>
		<!-- END LOADER -->

		<?php if(config('frontend.maintenance') == 'on'): ?>

			<div class="container h-100vh">
				<div class="row text-center h-100vh align-items-center">
					<div class="col-md-12">
						<img src="<?php echo e(URL::asset('img/files/maintenance.png')); ?>" alt="Maintenance Image">
						<h2 class="mt-4 font-weight-bold">We are just tuning up a few things.</h2>
						<h5>We apologize for the inconvenience but <span class="font-weight-bold text-info"><?php echo e(config('app.name')); ?></span> is currenlty undergoing planned maintenance.</h5>
					</div>
				</div>
			</div>
		<?php else: ?>

			<!-- Page -->
			<div class="page">
				<div class="page-main">

					<!-- App-Content -->
					<div class="main-content">
						<div class="side-app">

							<?php echo $__env->yieldContent('content'); ?>

						</div>
					</div>

			</div><!-- End Page -->

		<?php endif; ?>

		<?php echo $__env->make('layouts.footer-scripts-guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</body>
</html>


<?php /**PATH /Users/softedel/Documents/GitHub/voiceller/Voiceller/cloudpolly/resources/views/layouts/auth.blade.php ENDPATH**/ ?>