<!-- Jquery js-->
<script src="<?php echo e(URL::asset('js/jquery-3.6.0.min.js')); ?>"></script>

<!-- Bootstrap4 js-->
<script src="<?php echo e(URL::asset('plugins/bootstrap/popper.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

<?php echo $__env->yieldContent('js'); ?>

<!-- Custom js-->
<script src="<?php echo e(URL::asset('js/custom.js')); ?>"></script>
<?php /**PATH /Users/softedel/Downloads/cloud-polly-1.0.1/cloudpolly/resources/views/layouts/footer-scripts-guest.blade.php ENDPATH**/ ?>