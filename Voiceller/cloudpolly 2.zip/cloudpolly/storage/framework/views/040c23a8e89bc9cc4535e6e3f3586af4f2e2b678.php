<!--Favicon -->
<link rel="icon" href="<?php echo e(URL::asset('img/brand/favicon.svg')); ?>" type="image/x-icon"/>

<!-- Animate css -->
<link href="<?php echo e(URL::asset('css/animated.css')); ?>" rel="stylesheet" />

<!--Sidemenu css -->
<link href="<?php echo e(URL::asset('css/sidemenu.css')); ?>" rel="stylesheet">

<!-- P-scroll bar css-->
<link href="<?php echo e(URL::asset('plugins/p-scrollbar/p-scrollbar.css')); ?>" rel="stylesheet" />

<!---Icons css-->
<link href="<?php echo e(URL::asset('css/icons.css')); ?>" rel="stylesheet" />

<?php echo $__env->yieldContent('css'); ?>

<!-- Style css -->
<link href="<?php echo e(URL::asset('css/app.css')); ?>" rel="stylesheet" />

<!-- Simplebar css -->
<link href="<?php echo e(URL::asset('plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet">

<!-- Color Skin CSS -->
<link href="<?php echo e(URL::asset('css/color.css')); ?>" rel="stylesheet" />

<?php /**PATH /Users/softedel/Downloads/cloud-polly-1.0.1/cloudpolly/resources/views/layouts/header.blade.php ENDPATH**/ ?>