<!-- Jquery js-->
<script src="{{URL::asset('js/jquery-3.6.0.min.js')}}"></script>

<!-- Bootstrap4 js-->
<script src="{{URL::asset('plugins/bootstrap/popper.min.js')}}"></script>
<script src="{{URL::asset('plugins/bootstrap/js/bootstrap.min.js')}}"></script>

@yield('js')

<!-- Custom js-->
<script src="{{URL::asset('js/custom.js')}}"></script>
